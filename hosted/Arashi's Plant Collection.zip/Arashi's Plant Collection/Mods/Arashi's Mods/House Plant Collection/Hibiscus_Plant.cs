namespace Eco.Mods.TechTree
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Eco.Gameplay.Blocks;
    using Eco.Gameplay.Components;
    using Eco.Gameplay.Components.Auth;
    using Eco.Gameplay.DynamicValues;
    using Eco.Gameplay.Economy;
    using Eco.Gameplay.Housing;
    using Eco.Gameplay.Interactions;
    using Eco.Gameplay.Items;
    using Eco.Gameplay.Minimap;
    using Eco.Gameplay.Objects;
    using Eco.Gameplay.Players;
    using Eco.Gameplay.Property;
    using Eco.Gameplay.Skills;
    using Eco.Gameplay.Systems.TextLinks;
    using Eco.Gameplay.Pipes.LiquidComponents;
    using Eco.Gameplay.Pipes.Gases;
    using Eco.Gameplay.Systems.Tooltip;
    using Eco.Shared;
    using Eco.Shared.Math;
    using Eco.Shared.Serialization;
    using Eco.Shared.Utils;
    using Eco.Shared.View;
    using Eco.Shared.Items;
    using Eco.Gameplay.Pipes;
    using Eco.World.Blocks;
    
    [Serialized]    
    [RequireComponent(typeof(AttachmentComponent))]
    [RequireComponent(typeof(PropertyAuthComponent))]
    [RequireComponent(typeof(MinimapComponent))]                
    [RequireComponent(typeof(HousingComponent))]                          
    public partial class Arashi_Hibiscus_PlantObject : WorldObject
    {
        public override string FriendlyName { get { return "Hibiscus Plant"; } } 


        protected override void Initialize()
        {
            this.GetComponent<MinimapComponent>().Initialize("Housing");                                 
            this.GetComponent<HousingComponent>().Set(Arashi_Hibiscus_PlantItem.HousingVal);                                



        }

        public override void Destroy()
        {
            base.Destroy();
        }
       static Arashi_Hibiscus_PlantObject()
    {
        AddOccupancyList(typeof(Arashi_Hibiscus_PlantObject), new BlockOccupancy(Vector3i.Zero, typeof(WorldObjectBlock)));
        AddOccupancyList(typeof(Arashi_Hibiscus_PlantObject), new BlockOccupancy(new Vector3i(0,1,0), typeof(WorldObjectBlock)));
    }
    }

    [Serialized]
    public partial class Arashi_Hibiscus_PlantItem : WorldObjectItem<Arashi_Hibiscus_PlantObject>
    {
        public override string FriendlyName { get { return "Hibiscus Plant"; } } 
        public override string Description { get { return "Sometimes you just want to bring a little bit of nature into your house."; } }

        static Arashi_Hibiscus_PlantItem()
        {
            
        }
        
        [TooltipChildren] public HousingValue HousingTooltip { get { return HousingVal; } }
        [TooltipChildren] public static HousingValue HousingVal { get { return new HousingValue() 
                                                {
                                                    Category = "General",
                                                    Val = 1,
                                                    TypeForRoomLimit = "Decoration",
                                                    DiminishingReturnPercent = 0.75f
                                                };}}       
    }


    [RequiresSkill(typeof(BasicCraftingSkill), 3)]
    public partial class Arashi_Hibiscus_PlantRecipe : Recipe
    {
        public Arashi_Hibiscus_PlantRecipe()
        {
            this.Products = new CraftingElement[]
            {
                new CraftingElement<Arashi_Hibiscus_PlantItem>(),          
            };
            this.Ingredients = new CraftingElement[]
            {
               
				new CraftingElement<StoneItem>(typeof(BasicCraftingEfficiencySkill), 10, BasicCraftingEfficiencySkill.MultiplicativeStrategy),
                new CraftingElement<PlantFibersItem>(typeof(BasicCraftingEfficiencySkill), 7, BasicCraftingEfficiencySkill.MultiplicativeStrategy),

            };
            this.CraftMinutes = CreateCraftTimeValue(typeof(Arashi_Hibiscus_PlantRecipe), Item.Get<Arashi_Hibiscus_PlantItem>().UILink(), 2, typeof(MechanicsAssemblySpeedSkill));    
            this.Initialize("Hibiscus Plant", typeof(Arashi_Hibiscus_PlantRecipe));

            CraftingComponent.AddRecipe(typeof(FarmersTableObject), this);
        }
    }
}